Welcome to Team 5 project!

Please follow the below steps to be able to run and understand our research study.

Steps:
1. team5_Enverus_final_report.pdf

2. Code folder
	2.1. Install requirements.txt
		2.1.1. Open Command Prompt
		2.1.2. Navigate to file directory from Command Prompt
		2.1.3. Paste: pip install -r requirements.txt
		2.1.4. Press enter
	2.2. Open Solar_Generation_Forecasting.ipynb
		2.1.1. Run All cells
